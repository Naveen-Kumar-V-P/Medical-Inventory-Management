import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime
import pickle
import matplotlib.pyplot as plt
from statsmodels.tsa.arima.model import ARIMA

# Function to load model
def load_model(filename):
    with open(filename, 'rb') as file:
        return pickle.load(file)

# Load models
models = {
    'MULTIPLE ELECTROLYTES 500ML IVF': load_model('drug_1.pkl'),
    'SODIUM CHLORIDE IVF 100ML': load_model('drug_2.pkl'),
    'SODIUM CHLORIDE 0.9%': load_model('drug_3.pkl'),
    'ONDANSETRON 2MG/ML': load_model('drug_4.pkl'),
    'PANTOPRAZOLE 40MG INJ': load_model('drug_5.pkl'),
    'PARACETAMOL 1GM IV INJ': load_model('drug_6.pkl'),
    'WATER FOR INJECTION 10ML SOLUTION': load_model('drug_7.pkl'),
    'LIGNOCAINE HYDROCHLORIDE 2% INJ': load_model('drug_8.pkl'),
    'PIPERACILLIN 4GM+ TAZOBACTAM 500MG': load_model('drug_9.pkl'),
    'LEVOSALBUTAMOL/LEVALBUTEROL 0.63MG RESPULES': load_model('drug_10.pkl')
}

# Streamlit App
st.title('Drug Sales Forecasting')

# Dropdown to select drug
drug_name = st.selectbox('Select Drug', list(models.keys()))

# Number of months to forecast
months_to_forecast = st.slider('Months to Forecast', 1, 24, 12)

# Load the selected model
model = models[drug_name]

# Display and plot the forecasts
if st.button('Forecast'):
    # Perform prediction
    pred = model.predict(start=len(model.data.endog), end=len(model.data.endog) + months_to_forecast - 1, typ='levels')

    # Plotting
    fig, ax = plt.subplots()
    ax.plot(pred, label='Forecasted')
    ax.legend()
    st.pyplot(fig)
    st.write(pred)

# File uploader for new data
uploaded_file = st.file_uploader("Choose a CSV file", type="csv")

if uploaded_file is not None:
    # Read the uploaded file
    df = pd.read_csv(uploaded_file)
    st.write(df.head())

    # Assuming the new data contains Dateofbill and Quantity columns
    df['Dateofbill'] = pd.to_datetime(df['Dateofbill'])
    df = df.set_index('Dateofbill')

    # Plot the uploaded data
    st.line_chart(df['Quantity'])


